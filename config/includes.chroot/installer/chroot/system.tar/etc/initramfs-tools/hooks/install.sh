#!/bin/sh
. /usr/share/initramfs-tools/hook-functions
copy_exec /usr/bin/cut /usr/bin/cut
copy_exec /etc/initramfs-tools/scripts/local-top/crypt.sh /scripts/local-top/crypt.sh
