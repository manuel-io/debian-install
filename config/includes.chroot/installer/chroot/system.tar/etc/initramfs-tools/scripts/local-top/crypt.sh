#!/bin/sh

PREREQ="lvm"

prereqs()
{
  echo "FoorBar"
  echo "${PREREQ}"
}

case $1 in
prereqs)
  prereqs
  exit 0
  ;;
esac

cryptopen="/sbin/cryptsetup luksOpen /dev/sda2 linux"
cryptkeyscript="/lib/cryptsetup/askpass"
cryptkey="Please unlock Linux: "
derived="/sbin/dmsetup table /dev/mapper/linux --showkeys"

$cryptkeyscript "$cryptkey" | $cryptopen
$derived | /usr/bin/cut -d\  -sf 5 | /sbin/cryptsetup luksOpen /dev/sda3 users

echo "Filesystem ready!"
